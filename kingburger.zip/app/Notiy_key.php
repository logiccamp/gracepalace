<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Notiy_key extends Model
{
    protected $table = 'food_notification';
    protected $primaryKey = 'id';
}
?>