<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    protected $table = 'food_send_notification';
    protected $primaryKey = 'id';
}
?>