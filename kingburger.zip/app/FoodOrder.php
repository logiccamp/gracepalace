<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FoodOrder extends Model
{
    protected $table = 'food_order_response';
    protected $primaryKey = 'id';
}
?>