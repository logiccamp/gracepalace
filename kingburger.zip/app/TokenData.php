<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TokenData extends Model
{
    protected $table = 'food_tokandata';
    protected $primaryKey = 'id';
}
