<style type="text/css">
         
    .kb-text-box h2:after{
        background:<?=Session::get("webcolor")?> !important;
        border: 2px solid <?=Session::get("webcolor")?> !important;
    }

   .first-section .img{
        background-image: url(<?=Session::get("main_banner")?>) !important;
    }

    .footer-section {
      background-image: url(<?=Session::get("footer_img")?>) !important;
   }

   .about-text h5:after {
        background:<?=Session::get("webcolor")?> !important;
      border: 2px solid <?=Session::get("webcolor")?> !important;
   }

   .heading h1 {
    
      color: <?=Session::get("webcolor")?> !important;
   }

   .King_script_active:after {
      border-top: 23px solid <?=Session::get("webcolor")?> !important;
   }

   .King_script_active {
      background: <?=Session::get("webcolor")?> !important;
   }

   .head h1:after {
       background:<?=Session::get("webcolor")?> !important;
      border: 2px solid <?=Session::get("webcolor")?> !important;
   }

   .crl {
      background-color: <?=Session::get("webcolor")?> !important;
   }

   .fo-text h1:after {
       background:<?=Session::get("webcolor")?> !important;
      border: 2px solid <?=Session::get("webcolor")?> !important;
   }

   .detail-background-box {
      background-color: <?=Session::get("webcolor")?> !important;
   }

   .main-pizza-sb-2 {
      background-color: <?=Session::get("webcolor")?> !important;
   }

   .about-history h2 {
      color: <?=Session::get("webcolor")?> !important;
   }

   .about-content-1 p span {
      color: <?=Session::get("webcolor")?> !important;
   }

   .contact-head h1:after {
      border: 2px solid <?=Session::get("webcolor")?> !important;
   }

   .contact-head-1 h1:after {
      border: 2px solid <?=Session::get("webcolor")?> !important;
   }

   .contact-head .submit {
      background-color: <?=Session::get("webcolor")?> !important;
   }

   .login-modal .nav-tabs .nav-link.active, .nav-tabs .nav-item.show .nav-link {
      background-color: <?=Session::get("webcolor")?> !important;
   }

   .modal-login-button button {
      background-color: <?=Session::get("webcolor")?> !important;
   }

   .requiredfield {
      color: <?=Session::get("webcolor")?> !important;
   }

   .account-page-head h1 {
      color: <?=Session::get("webcolor")?> !important;
   }

   .pending-btn a {
      background-color: <?=Session::get("webcolor")?> !important;
   }

   .nav-pills .nav-link.active {
      background-color: <?=Session::get("webcolor")?> !important;
   }

   .btn-danger:hover {
      background-color: <?=Session::get("webcolor")?> !important;
      border-color: <?=session::get("webcolor")?> !important;
   }

   .acco-tab-content label span {
      color: <?=Session::get("webcolor")?> !important;
   }

   .acco-button .acco-u-button a {
      background-color: <?=Session::get("webcolor")?> !important;
   }

   .cart a:hover {
      background-color: <?=Session::get("webcolor")?> !important;
   }

   .detail-product-box .detail-product-head h4 {
      color: <?=Session::get("webcolor")?> !important;
   }

   .detail-ingredients .detail-ingredients-heading:after {
      border: 2px solid <?=Session::get("webcolor")?> !important;
   }

   .detail-product-box .detail-plus-add-cart {
      background-color: <?=Session::get("webcolor")?> !important;
   }

   .detail-related-head:after {
      border: 2px solid <?=Session::get("webcolor")?> !important;
      background-color: <?=Session::get("webcolor")?> !important;
   }

   .cart-bill-and-category .cart-head h1 {
      color: <?=Session::get("webcolor")?> !important;
   }

   .cart-category i.fa.fa-trash-o {
      color: <?=Session::get("webcolor")?> !important;
   }

   .checkout-but {
      background-color: <?=Session::get("webcolor")?> !important;
   }

   .cric {
      background-color: <?=Session::get("webcolor")?> !important;
   }

   .por-1 .price i {
      color: <?=Session::get("webcolor")?> !important;
   }

   .por-1 .b-text p {
      color: <?=Session::get("webcolor")?> !important;
   }

   .viewcart h1 a {
      background-color: <?=Session::get("webcolor")?> !important;
   }

   .accordion .card-header {
      border-top: 6px solid <?=Session::get("webcolor")?> !important;
   }

   .accordion.indicator-plus-before.round-indicator .card-header:before {
      color: <?=Session::get("webcolor")?> !important;
   }

   .card-body form span {
      color: <?=Session::get("webcolor")?> !important;
   }

   #orderplacepaypal button {
      background-color: <?=Session::get("webcolor")?> !important;
   }

   div#orderplacestrip .stripe-button-el {
      background-color: <?=Session::get("webcolor")?> !important;
   }

   div#orderplace1 button {
      background-color: <?=Session::get("webcolor")?> !important;
   }

   .order-d h1:after {
      border: 3px solid <?=Session::get("webcolor")?> !important;
   }

   .order-status ul .round-d {
      background-color: <?=Session::get("webcolor")?> !important;
   }

   .order-status ul .process-1:after {
      border: 3px solid <?=Session::get("webcolor")?> !important;
   }

   .order-d-text p {
      color: <?=Session::get("webcolor")?> !important;
   }
   .checkbox-acco1 a.card-title{
       color:<?=Session::get("webcolor")?> !important;
   }
   .card-body .sub input{
       background-color:<?=Session::get("webcolor")?> !important;
   }
   .logout-but .btn{
      background-color:<?=Session::get("webcolor")?> !important;
      border: 1px solid <?=Session::get("webcolor")?> !important;
   }

</style>