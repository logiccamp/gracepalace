<a href="//wa.link/iexij9" style="position : fixed; left : 4px; bottom : 10vh; z-index : 21212">
    <img src="/whatsapp_chat.png" style="height: 50px" alt="">
</a><?php /**PATH C:\lara\www\kingburger\resources\views/user/chat_icon.blade.php ENDPATH**/ ?>