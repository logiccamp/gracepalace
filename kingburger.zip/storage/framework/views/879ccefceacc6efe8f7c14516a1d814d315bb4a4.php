<div class="js-cookie-consent cookie-consent" id="cookie">

    <span class="cookie-consent__message">
        <?php echo e(__('messages.cookiemsg')); ?>

    </span>

    <button class="js-cookie-consent-agree cookie-consent__agree btn btn-danger">
        <?php echo e(__('messages.agree')); ?>

    </button>
    

</div>
<?php /**PATH C:\lara\www\kingburger\resources\views/vendor/cookieConsent/dialogContents.blade.php ENDPATH**/ ?>