<?php

return [
	'except' => [
		'password',
		'password_confirmation',
	],
];
