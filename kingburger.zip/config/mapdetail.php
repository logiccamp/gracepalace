<?php

return [
    
          "key"=>env('MAP_KEY'),
          "lat"=>env('MAP_LAT'),
          "long"=>env('MAP_LONG'),
          "web_color"=>env('WEB_COLOR'),
    ];